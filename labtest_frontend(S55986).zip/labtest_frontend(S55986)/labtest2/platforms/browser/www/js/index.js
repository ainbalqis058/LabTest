$(function () {
    var link1 = crossroads.addRoute("", function () {
        $("#divStaff").show();
        $("#divEmail").hide();

    });

    var link2 = crossroads.addRoute("", function () {
        $(".navbar-collapse li").removeClass("active");
        $(".navbar-collapse li").parent().addClass("active");
        var email = sessionStorage.ttoken;
        var datalist = "email=" + email;
        $.ajax({
            type: "post",
            url: "http://www.skimtech.my/ClassicModels/GetStaff",
            data: datalist,
            cache: false,
            success: function (mydata) {
                var myData = JSON.parse(mydata);
                var lastIndex = myData.length - 1;
                var htmlText = "";
                if (myData[lastIndex].status === 1) {
                    for (var i = 0; i < lastIndex; i++) {
                        htmlText = htmlText + "<tr><td>" + myData[i].id
                                + "</td><td><a href='#viewstaff/" + myData[i].id + "'>"+ myData[i].email
                               

                                + "</a></td></tr>";

                    }

                    $("#tblStaff tbody").html(htmlText);
                }

            },
            error: function () {
                console.log("ajax error!");
                alert("Please contact admin!");

            }
        });
        $("#divStaff").show();
        $("#divEmail").hide();

    });


    var link5 = crossroads.addRoute("/viewcstaff/{id}", function (id) {
        
        var datalist = "id=" + id;
        $.ajax({
            type: "post",
            url: "http://localhost:8084/ClassicModels/GetStaffById", 
            data: datalist,
            cache: false,
            success: function (mydata) {
                var myData = JSON.parse(mydata);
                if (myData.status === 1) {

                    document.getElementById("fname100").value = myData.fname;
                    document.getElementById("extension100").value = myData.extension;
                    document.getElementById("jobtitle100").value = myData.jobtitle;
                    document.getElementById("id100").value = myData.id;
                    document.getElementById("emailadd100").value = myData.email;
                    document.getElementById("lname100").value = myData.lname;

                }
                $("#divStaff").hide();
                $("#divEmail").show();

            },
            error: function () {
                console.log("ajax error!");
                alert("Please contact admin!");
            }

        });
    });

    function parseHash(newHash, oldHash) {
        crossroads.parse(newHash);
    }

    hasher.initialized.add(parseHash);
    hasher.changed.add(parseHash);
    hasher.init();


});