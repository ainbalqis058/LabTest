/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.api;

/**
 *
 * @author THINKPAD
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author THINKPAD
 */
public class ConMan {
    static Connection con;
    static String url;
    
    public static Connection getConnection(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            try{
                url="jdbc:mysql://localhost:3306/frontend_labtest";
                con=DriverManager.getConnection(url,"root","admin");  
            } catch(SQLException e){
                e.printStackTrace();
            }    
        }
        catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        return con;
    }
    
}
