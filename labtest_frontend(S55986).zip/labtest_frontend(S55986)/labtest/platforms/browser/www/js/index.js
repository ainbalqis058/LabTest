var link1 = crossroads.addRoute("/btnfather", function () {
$scope.CallNumber = function(){ 
    var number = '0164003625' ; 
    window.plugins.CallNumber.callNumber(function(){
     //success logic goes here
    }, function(){
     //error logic goes here
    }, number) 
  };
});